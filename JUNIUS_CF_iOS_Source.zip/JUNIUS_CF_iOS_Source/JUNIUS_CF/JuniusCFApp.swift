import SwiftUI

@main
struct JuniusCFApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}

struct ContentView: View {
    @State private var espPreview = false
    @State private var aimPreview = false
    @State private var skinPreview = false
    @State private var showInfo = false

    private let red = Color(red: 0.95, green: 0.12, blue: 0.22)

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.19, green: 0.035, blue: 0.055), .black],
                startPoint: .top, endPoint: .bottom
            ).ignoresSafeArea()

            ScrollView {
                VStack(spacing: 22) {
                    HStack {
                        Text("JUNIUS ").foregroundStyle(.white) +
                        Text("CF").foregroundStyle(red)
                        Spacer()
                        Text("iOS DEMO · v1.0")
                            .font(.caption2.bold())
                            .foregroundStyle(.gray)
                    }
                    .font(.title2.black())
                    .tracking(1.5)

                    HStack(spacing: 16) {
                        ZStack {
                            Circle().fill(red.gradient).frame(width: 76, height: 76)
                            Circle().fill(.black).padding(5)
                            Text("J").font(.system(size: 43, weight: .black))
                                .foregroundStyle(red)
                        }
                        VStack(alignment: .leading, spacing: 6) {
                            Text("JUNIUS CONTROL").font(.headline)
                            Text("RED / BLACK EDITION")
                                .font(.caption2).tracking(1.4).foregroundStyle(.gray)
                            Label("LOCAL DEMO READY", systemImage: "circle.fill")
                                .font(.caption2.bold()).foregroundStyle(red)
                        }
                        Spacer(minLength: 0)
                    }
                    .padding(18)
                    .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 22))
                    .overlay(RoundedRectangle(cornerRadius: 22).stroke(red.opacity(0.35)))

                    sectionTitle("GÖRSEL TEST PANELİ")
                    toggleCard("ESP Preview", detail: "Yalnızca arayüz anahtarı", value: $espPreview)
                    toggleCard("Aim Assist Preview", detail: "Etkileşimsiz tasarım önizlemesi", value: $aimPreview)
                    toggleCard("Skin Preview", detail: "Görünüm paneli örneği", value: $skinPreview)

                    sectionTitle("PERFORMANS")
                    HStack(spacing: 12) {
                        statCard("60", label: "DEMO FPS")
                        statCard("v1.0", label: "BUILD")
                    }

                    Button { showInfo = true } label: {
                        Text("JUNIUS HAKKINDA")
                            .font(.subheadline.black()).tracking(1)
                            .frame(maxWidth: .infinity).padding()
                            .foregroundStyle(red)
                            .background(red.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
                            .overlay(RoundedRectangle(cornerRadius: 14).stroke(red.opacity(0.5)))
                    }

                    Text("Bu bağımsız görsel demodur. CounterFlame'e bağlanmaz, oyun belleğini değiştirmez ve oyun içi hile işlevi sunmaz.")
                        .font(.caption2).foregroundStyle(.gray)
                        .multilineTextAlignment(.center)
                }
                .padding(20)
            }
        }
        .alert("JUNIUS CF", isPresented: $showInfo) {
            Button("Tamam", role: .cancel) { }
        } message: {
            Text("JUNIUS CF bağımsız bir iOS arayüz demosudur.")
        }
    }

    private func sectionTitle(_ title: String) -> some View {
        HStack {
            Text(title).font(.caption.bold()).tracking(2).foregroundStyle(.gray)
            Spacer()
        }
    }

    private func toggleCard(_ title: String, detail: String, value: Binding<Bool>) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.subheadline.bold())
                Text(detail).font(.caption).foregroundStyle(.gray)
            }
            Spacer()
            Toggle(title, isOn: value).labelsHidden().tint(red)
        }
        .padding(16)
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.08)))
    }

    private func statCard(_ value: String, label: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(value).font(.title.bold()).foregroundStyle(red)
            Text(label).font(.caption2).tracking(1).foregroundStyle(.gray)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 16))
    }
}
