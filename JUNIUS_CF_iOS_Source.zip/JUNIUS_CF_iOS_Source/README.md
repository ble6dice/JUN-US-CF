# JUNIUS CF – iOS kaynak başlangıç paketi

Bu paket, kırmızı-siyah bağımsız bir SwiftUI arayüz demosunun kaynak kodudur.

## Önemli
- Bu ZIP bir IPA değildir; iPhone'a doğrudan kurulamaz.
- IPA derlemek için Xcode çalışan bir Mac veya desteklenen bir bulut macOS derleme hizmeti gerekir.
- Cihaza yüklemek için geçerli imzalama sertifikası ve provisioning profile gerekir.
- Arayüz anahtarları yalnızca demo durumunu değiştirir. CounterFlame'e bağlanmaz ve oyun içi hile işlevi sağlamaz.

## Dosya
`JUNIUS_CF/JuniusCFApp.swift` dosyası SwiftUI uygulama ekranını içerir.

## Derleme
Bir Mac'te Xcode'da yeni bir iOS App projesi oluşturup bu Swift dosyasını projeye ekleyin. Bundle Identifier belirleyin, ardından Xcode üzerinden cihaz veya dağıtım için derleyin ve uygun Apple imzalama ayarlarını yapılandırın.
