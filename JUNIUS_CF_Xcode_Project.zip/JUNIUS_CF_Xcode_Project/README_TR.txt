JUNIUS CF – Xcode proje paketi

Bu ZIP artık .xcodeproj proje dosyasını da içerir.

ÖNEMLİ:
- Bu dosya hâlâ IPA değildir.
- IPA oluşturmak için Xcode çalışan bir Mac veya güvenilir bir bulut macOS derleme ortamı gerekir.
- ESign kaynak kodunu derlemez; hazır IPA'yı uygun sertifika/provisioning profile ile imzalamaya yarar.
- Sertifika (.p12) ve özel anahtar şifreni kimseyle paylaşma.
- Uygulama yalnızca bağımsız görsel demo arayüzüdür; oyuna bağlanmaz ve hile/anti-cheat atlatma işlevi içermez.

Xcode'da açılacak dosya: JUNIUS_CF.xcodeproj
Bundle ID: com.juniuscf.demo
Minimum iOS: 16.0
